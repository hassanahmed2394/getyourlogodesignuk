<section class="cta2">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="wrap">
        	<h6>We’re partners in creativity</h6>
        	<h3>It is important to coordinate and communicate. As a result, we ensure complete customer service as our representatives remain available 24/7 for your assistance.</h3>
	        <a href="tel:<?php echo $number_val; ?>" class="btn-secondary-outline">Call Us now to get started </a>
	    </div>
      </div>
    </div>
  </div>
</section>