<?php
namespace NitroPack;

class DeviceType {
    const DESKTOP = "desktop";
    const TABLET  = "tablet";
    const MOBILE  = "mobile";
}
