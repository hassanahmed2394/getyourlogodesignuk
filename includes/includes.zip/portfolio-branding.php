<li class=" logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/1.png">
    <figure>
      <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/1.png">
    </figure>
  </a>
</li>
<li class=" logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/2.png">
    <figure>
      <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/2.png">
    </figure>
  </a>
</li>
<li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/3.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/3.png">
      </figure>
    </a>
  </li>

  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/4.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/4.png">
      </figure>
    </a>
  </li>
<li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/5.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/5.png">
      </figure>
    </a>
  </li>

  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/6.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/6.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/7.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/7.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/8.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/8.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/9.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/9.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/10.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/10.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/11.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/11.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/12.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/12.png">
      </figure>
    </a>
  </li>
 <!--  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/13.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/13.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/14.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/14.png">
      </figure>
    </a>
  </li>
  <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/15.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/15.png">
      </figure>
    </a>
  </li>

   <li class=" logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/branding/16.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/branding/16.png">
      </figure>
    </a>
  </li> -->
