<section class="cta">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>Get Your Logo Design is determined to provide exceptional branding, website and digital marketing solutions to business and brands. We help you create your brand. <a href="<?php echo $path;?>order" class="btn-secondary-outline">Let’s create brands that build businesses</a></h3>
        <h6>Give us a call<a href="tel:<?php echo $number_val; ?>"><?php echo $number_text; ?></a></h6>
      </div>
    </div>
  </div>
</section>