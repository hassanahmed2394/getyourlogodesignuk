<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
require_once  'constants.php';
$nitropack_wpe_purge_path = NULL;

function nitropack_passes_cookie_requirements() {
    $cookieStr = implode("|", array_keys($_COOKIE));
    $safeCookie = strpos($cookieStr, "comment_author") === false && strpos($cookieStr, "wp-postpass_") === false && empty($_COOKIE["woocommerce_items_in_cart"]);
    $loginCookies = array(defined('NITROPACK_LOGGED_IN_COOKIE') ? NITROPACK_LOGGED_IN_COOKIE : (defined(LOGGED_IN_COOKIE) ? LOGGED_IN_COOKIE : ''));
    $isUserLoggedIn = false;

    foreach ($loginCookies as $loginCookie) {
        if (!empty($_COOKIE[$loginCookie])) {
            $isUserLoggedIn = true;
            break;
        }
    }

    return $safeCookie && !$isUserLoggedIn;
}

function nitropack_activate() {
    nitropack_set_wp_cache_const(true);
    $htaccessFile = nitropack_trailingslashit(NITROPACK_DATA_DIR) . ".htaccess";
    if (!file_exists($htaccessFile) && nitropack_init_data_dir()) {
        file_put_contents($htaccessFile, "deny from all");
    }
    nitropack_install_advanced_cache();

    if (nitropack_is_wpe()) {
        WpeCommon::purge_varnish_cache();
    }

    if (nitropack_is_connected()) {
        nitropack_event("enable_extension");
    } else {
        setcookie("nitropack_after_activate_notice", 1, time() + 15);
    }
}

function nitropack_deactivate() {
    nitropack_set_wp_cache_const(false);
    nitropack_uninstall_advanced_cache();

    if (nitropack_is_wpe()) {
        WpeCommon::purge_varnish_cache();
    }

    if (nitropack_is_connected()) {
        nitropack_event("disable_extension");
    }
}

function nitropack_is_wpe() {
    return getenv('IS_WPE');
}

function nitropack_wpe_path_purge($paths) {
    global $nitropack_wpe_purge_path;

    if ($nitropack_wpe_purge_path && count($paths) == 1 && $paths[0] == ".*" && get_option('permalink_structure')) {
        return array(parse_url($nitropack_wpe_purge_path, PHP_URL_PATH) . ".*");
    }

    return $paths;
}

function nitropack_install_advanced_cache() {
    $templatePath = nitropack_trailingslashit(__DIR__) . "advanced-cache.php";
    if (file_exists($templatePath)) {
        $contents = file_get_contents($templatePath);
        $contents = str_replace("/*NITROPACK_FUNCTIONS_FILE*/", __FILE__, $contents);
        $contents = str_replace("/*LOGIN_COOKIES*/", '"' . LOGGED_IN_COOKIE . '"', $contents);

        $advancedCacheFile = nitropack_trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';
        if (WP_DEBUG) {
            return file_put_contents($advancedCacheFile, $contents);
        } else {
            return @file_put_contents($advancedCacheFile, $contents);
        }
    }
}

function nitropack_uninstall_advanced_cache() {
    $advancedCacheFile = nitropack_trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';
    if (file_exists($advancedCacheFile)) {
        if (WP_DEBUG) {
            return file_put_contents($advancedCacheFile, "");
        } else {
            return @file_put_contents($advancedCacheFile, "");
        }
    }
}

function nitropack_set_wp_cache_const($status) {
    $configFilePath = nitropack_trailingslashit(ABSPATH) . "wp-config.php";
    if (!file_exists($configFilePath)) return false;

    $newVal = sprintf("define( 'WP_CACHE', %s); // Modified by NitroPack\n", ($status ? "true" : "false") );
    $lines = file($configFilePath);
    $wpCacheFound = false;

    foreach ($lines as &$line) {
        if (preg_match("/define\s*\(\s*['\"](.*?)['\"]/", $line, $matches)) {
            if ($matches[1] == "WP_CACHE") {
                $line = $newVal;
                $wpCacheFound = true;
                break;
            }
        }
    }

    if (!$wpCacheFound) {
        if (!$status) return true; // No need to modify the file at all
        array_splice($lines, 1, 0, [$newVal]);
    }

    return WP_DEBUG ? file_put_contents($configFilePath, implode("", $lines)) : @file_put_contents($configFilePath, implode("", $lines));
}

function nitropack_init() {
    global $nitropack_wpe_purge_path;
    header('Cache-Control: no-cache');
    header('X-Nitro-Cache: MISS');
    $GLOBALS["NitroPack.tags"] = array();

    if (!empty($_GET["nitroWebhook"]) && !empty($_GET["token"]) && nitropack_validate_webhook_token($_GET["token"])) {
        if (get_option("nitropack-webhookToken") == $_GET["token"]) {
            switch($_GET["nitroWebhook"]) {
            case "config":
                nitropack_fetch_config();
                exit;
            case "cache_clear":
                if (!empty($_POST["url"])) {
                    if ($validatedUrl = esc_url($_POST["url"], array("http", "https"), "notdisplay")) {
                        nitropack_sdk_purge($validatedUrl);
                    }
                } else {
                    nitropack_sdk_purge();
                }
                exit;
            }
        }
    } else {
        if (nitropack_passes_cookie_requirements() && !(is_preview() || is_robots() || is_feed() || is_comment_feed() || is_trackback())) {
            $has_advanced_cache = defined( 'NITROPACK_ADVANCED_CACHE' );
            if (nitropack_is_wpe()) {
                add_action('shutdown', 'nitropack_purge_wpe_path_cache');
            }

            if (!$has_advanced_cache) { // This must be here, so we can serve cache even if advanced-cache.php is missing
                nitropack_check_remote_cache(true);
            } else {
                add_action('shutdown', 'nitropack_check_remote_cache');
            }

            add_action("parse_query", "nitropack_handle_page_tags");
            add_action('the_post', 'nitropack_handle_the_post');

            $active_plugins = apply_filters('active_plugins', get_option('active_plugins'));
            if (in_array('woocommerce-multilingual/wpml-woocommerce.php', $active_plugins, true) && (!isset($_COOKIE["np_wc_currency"]) || !isset($_COOKIE["np_wc_currency_language"]))) {
                $final_action_before_output = $has_advanced_cache ? 'nitropack_before_output' : 'wp_footer';
                add_action($final_action_before_output, 'set_wc_cookies');
            }

            add_action('shutdown', 'nitropack_log_tags');
        }
    }
}

function set_wc_cookies() {
    $wcCurrency = WC()->session->get("client_currency");
    $wcCurrencyLanguage = WC()->session->get("client_currency_language");
    if (!$wcCurrency) $wcCurrency = 0;
    if (!$wcCurrencyLanguage) $wcCurrencyLanguage = 0;
    setcookie('np_wc_currency', $wcCurrency, time() + (86400 * 7), "/");
    setcookie('np_wc_currency_language', $wcCurrencyLanguage, time() + (86400 * 7), "/");
}

function nitropack_check_remote_cache($serve_cache = false) {
    static $isCacheRequested = false;
    global $nitropack_wpe_purge_path;

    if ($isCacheRequested) return;
    if (is_preview() || is_404()) return;

    foreach (headers_list() as $header) {
        if (stripos(trim($header), "location") === 0) {
            return; // This will be a redirect, no need to check for cache
        }
    }

    if (!empty($GLOBALS["NitroPack.instance"])) {
        $nitro = $GLOBALS["NitroPack.instance"];
        $isCacheRequested = true;

        $layout = nitropack_get_layout();
        if (defined("ICL_LANGUAGE_CODE")) {
            $layout .= "-" . ICL_LANGUAGE_CODE; // Separate critical CSS based on the current WPML language
        }

        try {
            if ($nitro->hasRemoteCache($layout) && $serve_cache === true) {
                header('X-Nitro-Cache: HIT');
                $nitro->pageCache->readfile();
                exit;
            } else {
                $GLOBALS["NitroPack.tags"]["pageType:" . $layout] = 1;
            }
        } catch (\Exception $e) {}
    }
}

function nitropack_handle_page_tags() {
    $layout = nitropack_get_layout();
    
    if ($layout == "category") {
        $catId = get_query_var('cat');
        $GLOBALS["NitroPack.tags"]["category:" . $catId] = 1;
    }
}

function nitropack_validate_site_id($siteId) {
    if (!preg_match("/^([a-zA-Z]{32})$/", trim($siteId), $matches)) {
        return false;
    }
    return $matches[1];
}

function nitropack_validate_site_secret($siteSecret) {
    if (!preg_match("/^([a-zA-Z0-9]{64})$/", trim($siteSecret), $matches)) {
        return false;
    }
    return $matches[1];
}

function nitropack_validate_webhook_token($token) {
    return preg_match("/^([abcdef0-9]{32})$/", strtolower($token));
}

function nitropack_validate_wc_currency($cookieValue) {
    return preg_match("/^([a-z]{3})$/", strtolower($cookieValue));
}

function nitropack_validate_wc_currency_language($cookieValue) {
    return preg_match("/^([a-z_\\-]{2,})$/", strtolower($cookieValue));
}

/** Step 3. */
function nitropack_options() {
    if ( !current_user_can( 'manage_options' ) )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }

    wp_enqueue_style('nitropack_bootstrap_css', plugin_dir_url(__FILE__) . 'view/stylesheet/bootstrap.min.css');
    wp_enqueue_style('nitropack_css', plugin_dir_url(__FILE__) . 'view/stylesheet/nitropack.css');
    wp_enqueue_style('nitropack_font-awesome_css', plugin_dir_url(__FILE__) . 'view/stylesheet/fontawesome/font-awesome.min.css', true);
    wp_enqueue_script('nitropack_bootstrap_js', plugin_dir_url(__FILE__) . 'view/javascript/bootstrap.min.js', true);
    wp_enqueue_script('nitropack_notices_js', plugin_dir_url(__FILE__) . 'view/javascript/np_notices.js', true);
    wp_enqueue_script('nitropack_embed_js', 'https://nitropack.io/asset/js/embed.js', true);

    $siteId = esc_attr( get_option('nitropack-siteId') );
    $siteSecret = esc_attr( get_option('nitropack-siteSecret') );
    $enableCompression = get_option('nitropack-enableCompression');
    $checkedCompression = get_option('nitropack-checkedCompression');

    if (empty($siteId) || empty($siteSecret)) {
        include plugin_dir_path(__FILE__) . nitropack_trailingslashit('view') . 'connect.php';
    } else {
        $widgetOptimizations = get_nitropack_integration_url("optimizations");
        $widgetPlan = get_nitropack_integration_url("plan");
        $widgetQuicksetup = get_nitropack_integration_url("quicksetup");
        $widgetBeforeafter = get_nitropack_integration_url("beforeafter");
        
        include plugin_dir_path(__FILE__) . nitropack_trailingslashit('view') . 'admin.php';
    }
}

function nitropack_is_connected() {
    $siteId = esc_attr( get_option('nitropack-siteId') );
    $siteSecret = esc_attr( get_option('nitropack-siteSecret') );
    return !empty($siteId) && !empty($siteSecret);
}

function nitropack_print_notice($type, $message) {
    echo '<div class="notice notice-' . $type . ' is-dismissible">';
    echo '<p><strong>NitroPack:</strong> ' . $message . '</p>';
    echo '</div>';
}

function nitropack_admin_notices() {
    if (!empty($_COOKIE["nitropack_after_activate_notice"])) {
        nitropack_print_notice("info", "NitroPack has been successfully activated, but it is not connected yet. Please go to <a href='" . admin_url( 'options-general.php?page=nitropack' ) . "'>its settings</a> page to connect it in order to start opitmizing your site!");
    }

    if (nitropack_is_connected()) {
        if (!defined("NITROPACK_ADVANCED_CACHE")) {
            if (nitropack_install_advanced_cache()) {
                nitropack_print_notice("warning", "The file /wp-content/advanced-cache.php was either missing or not the one generated by NitroPack. NitroPack re-installed its version of the file, so it can function properly. Possibly there is another active page caching plugin in your system. For correct operation, please deactivate any other page caching plugins.");
            } else {
                nitropack_print_notice("error", "The file /wp-content/advanced-cache.php cannot be created. This can lead to slower cache delivery. Please make sure that the /wp-content/ directory is writable and refresh this page.");
            }
        }

        if ( (!defined("WP_CACHE") || !WP_CACHE) && !nitropack_set_wp_cache_const(true)) {
            nitropack_print_notice("error", "The WP_CACHE constant cannot be set in the wp-config.php file. This can lead to slower cache delivery. Please make sure that the /wp-config.php file is writable and refresh this page.");
        }

        if ( !nitropack_data_dir_exists() && !nitropack_init_data_dir()) {
            nitropack_print_notice("error", "The NitroPack data directory cannot be created. Please make sure that the /wp-content/ directory is writable and refresh this page.");
            return;
        }

        $siteId = esc_attr( get_option('nitropack-siteId') );
        $siteSecret = esc_attr( get_option('nitropack-siteSecret') );
        $blogId = get_current_blog_id();

        if ( !nitropack_config_exists() && !nitropack_update_current_blog_config($siteId, $siteSecret, $blogId)) {
            nitropack_print_notice("error", "The NitroPack static config file cannot be created. Please make sure that the /wp-content/nitropack/ directory is writable and refresh this page.");
        }
    }
}

function get_nitropack_sdk($siteId = null, $siteSecret = null, $blogId = null) {
    if ($blogId === null) $blogId = get_current_blog_id();

    require_once 'nitropack-sdk/autoload.php';
    $siteId = $siteId ? $siteId : get_option('nitropack-siteId');
    $siteSecret = $siteSecret ? $siteSecret : get_option('nitropack-siteSecret');

    if ($siteId && $siteSecret) {
        try {
            $dataDir = nitropack_trailingslashit(NITROPACK_DATA_DIR) . $blogId; // dir without a trailing slash, because this is how the SDK expects it
            $nitro = new NitroPack\NitroPack($siteId, $siteSecret, $_SERVER["HTTP_USER_AGENT"], NULL, $dataDir);
        } catch (\Exception $e) {
            return NULL;
        }
        
        return $nitro;
    }
}

function get_nitropack_integration_url($integration, $nitro = null) {
    if ($nitro || (null !== $nitro = get_nitropack_sdk()) ) {
        return $nitro->integrationUrl($integration);
    }

    return "#";
}

function register_nitropack_settings() {
    register_setting( NITROPACK_OPTION_GROUP, 'nitropack-siteId', array('show_in_rest' => false) );
    register_setting( NITROPACK_OPTION_GROUP, 'nitropack-siteSecret', array('show_in_rest' => false) );
    register_setting( NITROPACK_OPTION_GROUP, 'nitropack-enableCompression', array('default' => -1) );
}

function nitropack_get_layout() {
    $layout = "default";

    if (is_home()) {
        $layout = "home";
    } else if (is_page()) {
        $layout = "page";
    } else if (is_attachment()) {
        $layout = "attachment";
    } else if (is_single()) {
        $layout = "post";
    } else if (is_category()) {
        $layout = "category";
    } else if (is_archive()) {
        $layout = "archive";
    } else if (is_author()) {
        $layout = "author";
    } else if (is_search()) {
        $layout = "search";
    }

    return $layout;
}

function nitropack_sdk_invalidate($url = NULL, $tag = NULL, $reason = NULL) {
    if (null !== $nitro = get_nitropack_sdk()) {
        try {
            $nitro->invalidateCache($url, $tag, $reason);

            if (nitropack_is_wpe()) {
                if ($url) {
                    $nitropack_wpe_purge_path = parse_url($url, PHP_URL_PATH);
                    add_filter( 'wpe_purge_varnish_cache_paths', 'nitropack_wpe_path_purge' );
                }
                WpeCommon::purge_varnish_cache();
            }
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    return false;
}

function nitropack_sdk_purge($url = NULL, $reason = NULL) {
    if (null !== $nitro = get_nitropack_sdk()) {
        try {
            $nitro->purgeCache($url, NULL, \NitroPack\PurgeType::COMPLETE, $reason);

            if (nitropack_is_wpe()) {
                if ($url) {
                    $nitropack_wpe_purge_path = parse_url($url, PHP_URL_PATH);
                    add_filter( 'wpe_purge_varnish_cache_paths', 'nitropack_wpe_path_purge' );
                }
                WpeCommon::purge_varnish_cache();
            }
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    return false;
}

function nitropack_fetch_config() {
    if (null !== $nitro = get_nitropack_sdk()) {
        try {
            $nitro->fetchConfig();
        } catch (\Exception $e) {}
    }
}

function nitropack_switch_theme() {
    try {
        nitropack_sdk_purge(NULL, 'Theme switched'); // purge entire cache
    } catch (\Exception $e) {}
}

function nitropack_purge_cache() {
    try {
        if (nitropack_sdk_purge(NULL, 'Manual purge of all pages')) {
            nitropack_json_and_exit(array(
                "type" => "success",
                "message" => "Success! Cache has been purged successfully!"
            ));
        }
    } catch (\Exception $e) {}

    nitropack_json_and_exit(array(
        "type" => "error",
        "message" => "Error! There was an error and the cache was not purged!"
    ));
}

function nitropack_invalidate_cache() {
    try {
        if (nitropack_sdk_invalidate(NULL, NULL, 'Manual invalidation of all pages')) {
            nitropack_json_and_exit(array(
                "type" => "success",
                "message" => "Success! Cache has been invalidated successfully!"
            ));
        }
    } catch (\Exception $e) {}

    nitropack_json_and_exit(array(
        "type" => "error",
        "message" => "Error! There was an error and the cache was not invalidated!"
    ));
}

function nitropack_json_and_exit($array) {
    echo json_encode($array);
    exit;
}

function nitropack_clean_post_cache($postID) {
    try {
        nitropack_sdk_invalidate(NULL, "post:$postID", "Updated post with ID #$postID");
        $posts = get_post_ancestors($postID);
        foreach ($posts as $parentID) {
            nitropack_sdk_invalidate(NULL, "post:$parentID", "Updated post with ID #postID");
        }
    } catch (\Exception $e) {}
}

function nitropack_clean_attachment_cache($attachmentID) {
    try {
        nitropack_sdk_invalidate(NULL, "attachment:$attachmentID", "Updated attachment with ID #$attachmentID");
        $posts = get_post_ancestors($attachmentID);
        foreach ($posts as $postID) {
            nitropack_sdk_invalidate(NULL, "post:$postID", "Updated attachment with ID #$attachmentID");
        }
    } catch (\Exception $e) {}
}

function nitropack_handle_the_post($post) {
    $GLOBALS["NitroPack.tags"]["post:" . $post->ID] = 1;
    $GLOBALS["NitroPack.tags"]["author:" . $post->post_author] = 1;
}

function nitropack_log_tags() {
    if (!empty($GLOBALS["NitroPack.instance"]) && !empty($GLOBALS["NitroPack.tags"])) {
        $nitro = $GLOBALS["NitroPack.instance"];
        try {
            $nitro->getApi()->tagUrl($nitro->getUrl(), array_keys($GLOBALS["NitroPack.tags"]));
        } catch (\Exception $e) {}
    }
}

function nitropack_purge_wpe_path_cache() {
    $nitropack_wpe_purge_path = $_SERVER['REQUEST_URI'];
    add_filter( 'wpe_purge_varnish_cache_paths', 'nitropack_wpe_path_purge' );
    WpeCommon::purge_varnish_cache();
}

function nitropack_verify_connect() {
    if (empty($_POST["siteId"]) || empty($_POST["siteSecret"]) ||
        !($siteId = nitropack_validate_site_id(esc_attr($_POST["siteId"]))) ||
        !($siteSecret = nitropack_validate_site_secret(esc_attr($_POST["siteSecret"])))) {
        nitropack_json_and_exit(array("status" => "error", "message" => "Site ID and Site Secret cannot be empty"));
    }
    try {
        $blogId = get_current_blog_id();
        if (null !== $nitro = get_nitropack_sdk($siteId, $siteSecret, $blogId)) {
            if ($nitro->fetchConfig()) {
                $token = md5(uniqid());
                update_option("nitropack-webhookToken", $token);
                update_option("nitropack-enableCompression", -1);

                $configUrl = new \NitroPack\Url(get_home_url() . "?nitroWebhook=config&token=$token");
                $cacheClearUrl = new \NitroPack\Url(get_home_url() . "?nitroWebhook=cache_clear&token=$token");

                $nitro->getApi()->setWebhook("config", $configUrl);
                $nitro->getApi()->setWebhook("cache_clear", $cacheClearUrl);

                // _icl_current_language is WPML cookie, it is added here for compatibility with this module
                $customVariationCookies = array("np_wc_currency", "np_wc_currency_language", "_icl_current_language");
                $variationCookies = $nitro->getApi()->getVariationCookies();
                foreach ($variationCookies as $cookie) {
                    $index = array_search($cookie["name"], $customVariationCookies);
                    if ($index !== false) {
                        array_splice($customVariationCookies, $index, 1);
                    }
                }

                foreach ($customVariationCookies as $cookieName) {
                    $nitro->getApi()->setVariationCookie($cookieName);
                }

                $nitro->fetchConfig(); // Reload the variation cookies

                nitropack_update_current_blog_config($siteId, $siteSecret, $blogId);
                nitropack_install_advanced_cache();

                if (nitropack_is_wpe()) {
                    WpeCommon::purge_varnish_cache();
                }

                nitropack_event("connect", $nitro);

                nitropack_json_and_exit(array("status" => "success"));
            }
        }
    } catch (\Exception $e) {
        nitropack_json_and_exit(array("status" => "error", "message" => "Incorrect API credentials. Please make sure that you copied them correctly and try again."));
    }

    nitropack_json_and_exit(array("status" => "error"));
}

function nitropack_handle_disconnect() {
    nitropack_uninstall_advanced_cache();
    nitropack_event("disconnect");
}

function nitropack_test_compression() {
    $hasCompression = true;
    try {
        require_once plugin_dir_path(__FILE__) . nitropack_trailingslashit('nitropack-sdk') . 'autoload.php';
        $http = new NitroPack\HttpClient(get_site_url());
        $http->setHeader("X-NitroPack-Request", 1);
        $http->timeout = 25;
        $http->fetch();
        $headers = $http->getHeaders();
        if (!empty($headers["content-encoding"]) && strtolower($headers["content-encoding"]) == "gzip") { // compression is present, so there is no need to enable it in NitroPack. We only check for GZIP, because this is the only supported compression in the HttpClient
            update_option("nitropack-enableCompression", 0);
            $hasCompression = true;
        } else { // no compression, we must enable it from NitroPack
            update_option("nitropack-enableCompression", 1);
            $hasCompression = false;
        }
        update_option("nitropack-checkedCompression", 1);
    } catch (\Exception $e) {
        nitropack_json_and_exit(array("status" => "error"));
    }

    nitropack_json_and_exit(array("status" => "success", "hasCompression" => $hasCompression));
}

function nitropack_handle_compression_toggle() {
    $new_value = get_option("nitropack-enableCompression"); // Unfortunately WordPress is not feeding in the $new_value as a function argument, even though the documentation says it should be. This is why we have to do this ugly thing...
    nitropack_update_blog_compression($new_value == 1);
}

function nitropack_update_blog_compression($enableCompression = false) {
    if (nitropack_is_connected()) {
        $siteId = esc_attr( get_option('nitropack-siteId') );
        $siteSecret = esc_attr( get_option('nitropack-siteSecret') );
        $blogId = get_current_blog_id();
        nitropack_update_current_blog_config($siteId, $siteSecret, $blogId, $enableCompression);
    }
}

function nitropack_data_dir_exists() {
    return defined("NITROPACK_DATA_DIR") && is_dir(NITROPACK_DATA_DIR);
}

function nitropack_init_data_dir() {
    return nitropack_data_dir_exists() || @mkdir(NITROPACK_DATA_DIR, 0755, true);
}

function nitropack_config_exists() {
    return defined("NITROPACK_CONFIG_FILE") && file_exists(NITROPACK_CONFIG_FILE);
}

function nitropack_set_config($config) {
    if (!nitropack_data_dir_exists() && !nitropack_init_data_dir()) return false;
    return WP_DEBUG ? file_put_contents(NITROPACK_CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT)) : @file_put_contents(NITROPACK_CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT));
}

function nitropack_get_config() {
    $config = array();

    if (nitropack_config_exists()) {
        $config = json_decode(file_get_contents(NITROPACK_CONFIG_FILE), true);
    }

    return $config;
}

function nitropack_update_current_blog_config($siteId, $siteSecret, $blogId, $enableCompression = null) {
    if ($enableCompression === null) {
        $enableCompression = (get_option('nitropack-enableCompression') == 1);
    }

    $configKey = preg_replace("/^https?:\/\/(.*)/", "$1", get_home_url());
    $staticConfig = nitropack_get_config();
    $staticConfig[$configKey] = array(
        "siteId" => $siteId,
        "siteSecret" => $siteSecret,
        "blogId" => $blogId,
        "compression" => $enableCompression
    );
    return nitropack_set_config($staticConfig);
}

function nitropack_event($event, $nitro = null) {
    global $wp_version;

    try {
        $eventUrl = get_nitropack_integration_url("extensionEvent", $nitro);
        $domain = !empty($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : "Unknown";

        $query_data = array(
            'event' => $event,
            'platform' => 'WordPress',
            'platform_version' => $wp_version,
            'nitropack_extension_version' => NITROPACK_VERSION,
            'additional_meta_data' => "{}",
            'domain' => $domain
        );

        $client = new NitroPack\HttpClient($eventUrl . '&' . http_build_query($query_data));
        $client->doNotDownload = true;
        $client->fetch();
    } catch (\Exception $e) {}
}
