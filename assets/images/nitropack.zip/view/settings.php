<div class="alert alert-info" role="alert" style="margin-top: 10px;"><p>You can configure how NitroPack's optimization behaves though your account at <a href="https://nitropack.io/" taregt="_blank">https://nitropack.io/&nbsp;&nbsp;<i class="fa fa-external-link"></i></a>.</p></div>
<table class="form-table">
  <tr valign="top">
    <th scope="row">Site ID</th>
    <td><input type="text" name="nitropack-siteId" value="<?php echo $siteId; ?>" /></td>
  </tr>

  <tr valign="top">
    <th scope="row">Site Secret</th>
    <td><input type="text" name="nitropack-siteSecret" value="<?php echo $siteSecret; ?>" /></td>
  </tr>

  <tr valign="top">
    <th scope="row"></th>
    <td><i id="disconnect-spinner" class="fa fa-spinner fa-spin white" style="display:none;"></i><a class="button" id="disconnect-btn">Disconnect</a></td>
  </tr>

  <tr valign="top">
    <th scope="row">Compression</th>
    <td>
      <span id="compression-test-message" style="display:none;">Testing current compression status&nbsp;&nbsp;<i class="fa fa-spinner fa-spin"></i>&nbsp;&nbsp;</span>
      <select name="nitropack-enableCompression" id="compression-setting">
        <option value="1" <?php echo (int)$enableCompression === 1 ? "selected" : ""; ?>>Enabled</option>
        <option value="0"<?php echo (int)$enableCompression !== 1 ? "selected" : ""; ?>>Disabled</option>
      </select>
      <a class="button" id="compression-test-btn">Test whether compression is needed</a>
    </td>
  </tr>
</table>

<script>
(function($) {
  var autoDetectCompression = function() {
    $("#compression-test-message").show();
    $("#compression-test-btn").hide();
    $("#compression-setting").hide();

    $.post(ajaxurl, {
        action: 'nitropack_test_compression'
    }, function(response) {
      $("#compression-test-message").hide();

      var resp = JSON.parse(response);
      if (resp.status == "success") {
        if (resp.hasCompression) { // compression already enabled
          $("#compression-setting").val(0);
        } else { // no compression - enable ours
          $("#compression-setting").val(1);
        }
      } else {
        jQuery('#wpbody-content').prepend('<div class="notice notice-error is-dismissible"><p>Error! Could not determine compression status automatically. Please configure it manually.</p></div>');
      }
      $("#compression-test-btn").show();
      $("#compression-setting").show();
    });
  }

  var disconnectButton = function() {
    if (confirm("Are you sure? This will disconnect the plugin and NitroPack.io will stop working.")) {
      $("#disconnect-btn").hide();
      $("#disconnect-spinner").show();

      $.ajax({
        url: ajaxurl,
        type: "POST",
        data: {
          action: "nitropack_handle_disconnect"
        },
        complete: function() {
          $('[name="nitropack-siteId"]').val("");
          $('[name="nitropack-siteSecret"]').val("");
          $('#submit').trigger('click');
        }
      });
    }
  }

  <?php if ($checkedCompression != 1) { ?>
    autoDetectCompression();
  <?php } ?>

  $(document).on('click', "#compression-test-btn", e => {
    e.preventDefault();

    autoDetectCompression();
  });

  $(document).on('click', "#disconnect-btn", e => {
    e.preventDefault();

    disconnectButton();
  });
})(jQuery);
</script>
