<div>
    <div class="row">
        <div class="col-md-6">
            <div class="integration-widget-container integration-widget-container-small">
                <iframe src="<?php echo $widgetOptimizations; ?>"></iframe>
            </div>
        </div>
        <div class="col-md-6">
            <div class="integration-widget-container integration-widget-container-small">
                <iframe src="<?php echo $widgetPlan; ?>"></iframe>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="integration-widget-container integration-widget-container-medium">
                <iframe src="<?php echo $widgetQuicksetup; ?>"></iframe>
            </div>
        </div>
        <div class="col-md-6">
            <div class="integration-widget-container integration-widget-container-medium">
                <iframe src="<?php echo $widgetBeforeafter; ?>"></iframe>
            </div>
        </div>
    </div>
</div>
