<div id="nitropack-container" class="wrap">
    <div id="heading">
        <h2>NitroPack.io</h2>
    </div>

    <form method="post" action="options.php" name="form">
        <?php settings_fields( NITROPACK_OPTION_GROUP ); ?>
        <?php do_settings_sections( NITROPACK_OPTION_GROUP ); ?>

        <ul class="nav nav-tabs nav-tab-wrapper">
            <li class="active"><a class="nav-tab active" href="#dashboard" data-toggle="tab">Dashboard</a></li>
            <li><a class="nav-tab" href="#settings" data-toggle="tab">Settings</a></li>
            <li><a class="nav-tab" href="#help" data-toggle="tab">Help</a></li>
        </ul>		
        <div class="tab-content">
            <div id="dashboard" class="tab-pane fade in active">
                <?php require_once "dashboard.php"; ?>
            </div>
            <div id="settings" class="tab-pane fade">
                <?php require_once "settings.php"; ?>
                <?php submit_button(); ?>
            </div>
            <div id="help" class="tab-pane fade">
                <?php require_once "help.php"; ?>
            </div>
        </div>
    </form>
</div>
<script>
(function($) {
    const Notification = (_ => {
        var timeout;

        var display = (msg, type) => {
            clearTimeout(timeout);
            $('#nitropack-notification').remove();

            $('[name="form"]').prepend('<div id="nitropack-notification" class="notice notice-' + type + '" is-dismissible"><p>' + msg + '</p></div>');

            timeout = setTimeout(_ => {
                $('#nitropack-notification').remove();
            }, 10000);
            loadDismissibleNotices();
        }

        return {
            success: msg => {
                display(msg, 'success');
            },
            error: msg => {
                display(msg, 'error');
            },
            info: msg => {
                display(msg, 'info');
            },
            warning: msg => {
                display(msg, 'warning');
            }
        }
    })();

    const clearCacheHandler = clearCacheAction => {
        return function(success, error) {
            $.ajax({
                url: ajaxurl,
                type: 'GET',
                data: {
                    action: clearCacheAction
                },
                dataType: 'json',
                beforeSend: function() {
                    Notification.info("Loading. Please wait...");
                },
                success: function(data) {
                    success();
                    Notification[data.type](data.message);
                }
            });
        };
    }

    $(window).load(_ => {
        NitroPack.Optimizations.setInvalidateCacheHandler(clearCacheHandler("nitropack_invalidate_cache"));
        NitroPack.Optimizations.setPurgeCacheHandler(clearCacheHandler("nitropack_purge_cache"));

        NitroPack.QuickSetup.setChangeHandler(async function(value, success, error) {
            success(value);
        });
    });
})(jQuery);
</script>
