<?php
/*
Plugin Name:  NitroPack
Plugin URI:   https://nitropack.io/download/plugin/nitropack-for-wordpress
Description:  A site performance optimization plugin
Version:      1.0
Author:       NitroPack LLC
Author URI:   https://nitropack.io/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
require_once 'functions.php';

add_action( 'clean_post_cache', 'nitropack_clean_post_cache' );
add_action( 'clean_attachment_cache', 'nitropack_clean_attachment_cache' );
add_action( 'switch_theme', 'nitropack_switch_theme' );

add_action('wcml_set_client_currency', function($currency) {
    setcookie('np_wc_currency', $currency, time() + (86400 * 7), "/");
});

if ( is_admin() ) {
    add_action( 'admin_menu', 'nitropack_menu' );
    add_action( 'admin_init', 'register_nitropack_settings' );
    add_action( 'admin_notices', 'nitropack_admin_notices' );
    add_action( 'network_admin_notices', 'nitropack_admin_notices' );
    add_action( 'wp_ajax_nitropack_purge_cache', 'nitropack_purge_cache' );
    add_action( 'wp_ajax_nitropack_invalidate_cache', 'nitropack_invalidate_cache' );
    add_action( 'wp_ajax_nitropack_verify_connect', 'nitropack_verify_connect' );
    add_action( 'wp_ajax_nitropack_handle_disconnect', 'nitropack_handle_disconnect' );
    add_action( 'wp_ajax_nitropack_test_compression', 'nitropack_test_compression' );
    add_action( 'update_option_nitropack-enableCompression', 'nitropack_handle_compression_toggle' );
    register_activation_hook( __FILE__, 'nitropack_activate' );
    register_deactivation_hook( __FILE__, 'nitropack_deactivate' );
} else {
    if (null !== $nitro = get_nitropack_sdk()) {
        $GLOBALS["NitroPack.instance"] = $nitro;
        if (get_option('nitropack-enableCompression') == 1) {
            $nitro->enableCompression();
        }
        add_action( 'wp', 'nitropack_init' );
    }
}

function nitropack_menu() {
    add_options_page( 'NitroPack Options', 'NitroPack', 'manage_options', 'nitropack', 'nitropack_options' );
    add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'nitropack_action_links' );
}

function nitropack_action_links ( $links ) {
    $nitroLinks = array(
        '<a href="' . admin_url( 'options-general.php?page=nitropack' ) . '">Settings</a>',
    );
    return array_merge( $nitroLinks, $links );
}
