=== NitroPack ===
Contributors: nitropack
Tags: nitropack,optimize,fast,pagespeed
Requires at least: 4.7
Tested up to: 5.2.1
Requires PHP: 5.3
Stable tag: trunk
License: GNU General Public License, version 2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A site performance optimization plugin

== Description ==
NitroPack uses wide array of techniques to achieve the best possible automated optimization on your website.

== Installation ==
After you have installed NitroPack IO, you will need an account at https://nitropack.io/.
Once you have registered, please proceed to add your website to your account by using the button in the top right.
Once that is done, you can paste the site ID and secret from https://nitropack.io/user/connect into the WordPress plugin in order to connect your website to your NitroPack IO account.

== Frequently Asked Questions ==
How NitroPack web performance tool works?
NitroPack analyzes Google PageSpeed Insights and Lighthouse results for your website. Then NitroPack will run its optimization robot to present the possible non-human-assisted optimizations your website can achieve with us.

What is Google PageSpeed Insights and Lighthouse?
Google PageSpeed Insights is the Google tool to measure how fast one website is and what needs to be done to make it faster. Lighthouse is the engine Google uses for this analysis.

What optimization features NitroPack provide?
NitroPack uses wide array of techniques to achieve the best-possible automated optimization on your website. You can learn more on our website <a href="https://nitropack.io/">https://nitropack.io/</a>.

== Screenshots ==
1. Connect your store
2. Dashboard - see and manage the data in your Nitropack.io
3. Widgets - your site performance at a glance

== Changelog ==
NitroPack 1.0
---------------------------------
- Initial release
