<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
define( 'NITROPACK_ADVANCED_CACHE', true);
define( 'NITROPACK_LOGGED_IN_COOKIE', /*LOGIN_COOKIES*/ );

require_once "/*NITROPACK_FUNCTIONS_FILE*/";

$isManageWpRequest = !empty($_GET["mwprid"]);
if ( file_exists(NITROPACK_CONFIG_FILE) && !empty($_SERVER["HTTP_HOST"]) && !empty($_SERVER["REQUEST_URI"]) && !$isManageWpRequest ) {
    try {
        $npConfig = nitropack_get_config();
        $currentUrl = $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
        $siteConfig = null;
        $matchLength = 0;
        foreach ($npConfig as $siteUrl => $config) {
            if (strpos($currentUrl, $siteUrl) === 0 && strlen($siteUrl) > $matchLength) {
                $siteConfig = $config;
                $matchLength = strlen($siteUrl);
            }
        }
        
        if ( $siteConfig && null !== $nitro = get_nitropack_sdk($siteConfig["siteId"], $siteConfig["siteSecret"], $siteConfig["blogId"]) ) {
            if (nitropack_passes_cookie_requirements()) {
                if (!empty($siteConfig["compression"])) {
                    $nitro->enableCompression();
                }

                if ($nitro->hasLocalCache()) {
                    header('X-Nitro-Cache: HIT');
                    header('Cache-Control: no-cache');
                    $nitro->pageCache->readfile();
                    exit;
                } else {
                    ob_start(function ($buf) use($nitro) {
                        do_action( "nitropack_before_output" );
                        ini_set('zlib.output_compression', 0);
                        header('Content-Encoding: none');
                        header('X-Accel-Buffering: no');
                        header("Content-Length: " . strlen($buf));
                        return $buf;
                    });
                    register_shutdown_function('ob_end_flush');
                }
            }
        }
    } catch (\Exception $e) {
        // Do nothing, cache serving will be handled by nitropack_init
    }
}
