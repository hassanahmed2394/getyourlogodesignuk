
  <div class="left">
    <h2>Let Brilliance Take Over</h2>
    <h3>Businesses from over the world have worked with us to create brands with utmost brilliance. We understand the importance of branding and make sure everything goes as per market needs, your ideology and our expertise.</p>
    <ul class="pointlisting">
      <li>Brand Identity</li>
      <li>Rebranding</li>
      <li>Stationery Design</li>
      <li>Print Design</li>
      <li>Packaging Design</li>
      
    </ul>
    <a href="<?php echo $path;?>order" class="btn-theme-outline">Brand your business in just $74.99</a>
  </div>
  <div class="right">
    <figure>
      <img src="<?php echo $basesurl;?>images/brandingimage.svg">
    </figure>
  </div>
