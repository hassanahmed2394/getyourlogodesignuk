<div class="smallboxes packagesslider">
  <div class="smallbox">
    <h2>$33.99 <span><s>$66.98</s></span> </h2>
    <h4>Special Logo <br> Package</h4>
    <p>Suitable for low level startups and brand revamps for companies.</p>
    <div class="hrline"></div>
    
    <ul class="ticklist2 list-scroll">
      <li>4 Logo Design Concepts</li>
      <li>2 Revisions</li>
      <li>1 Dedicated Designers</li>
      <li>24 - 48 hrs Turnaround Time</li>
      <li>File Format (JPG)</li>
      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/special-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=1" class="btn-packages">Place Your Order</a>
    </div>

  </div>

  <div class="smallbox">
    <h2>$55.99 <span><s>$110.98</s></span> </h2>
    <h4>Bronze Logo<br> Package</h4>
    <p>Suitable for mid-level startups and organizations.</p>
    <div class="hrline"></div>
    <!-- <h3>Payable Amount</h3> -->
    <ul class="ticklist2 list-scroll">
      <li>6 Logo Design Concepts</li>
      <li>5 Revisions</li>
      <li>2 Dedicated Designers</li>
      <li>24 - 48 hrs Turnaround Time</li>
      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
      
    </ul>
    
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/bronze-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=2" class="btn-packages">Place Your Order</a>
    </div>

  </div>

  <div class="smallbox">
    <h2>$88.99 <span><s>$176.98</s></span> </h2>
    <h4>Silver Logo<br> Package</h4>
    <p>Suitable for mid-level and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <!-- <h3>Payable Amount</h3> -->
    <ul class="ticklist2 list-scroll">
      <li>8 Logo Design Concepts</li>
      <li>Unlimited Revisions</li>
      <li>FREE Icon Design</li>
      <li>FREE Grayscale Format</li>
      <li>FREE Color Options</li>
      <li>FREE Vector Files</li>
      <li>4 Creative Designers</li>
      <li>48 hrs Turnaround Time</li>

      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
      
    </ul>
    
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/silver-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=3" class="btn-packages">Place Your Order</a>
    </div>

  </div>

  <div class="smallbox">
    <h2>$111.99 <span><s>$222.98</s></span> </h2>
    <h4>Gold Logo <br> Package</h4>
    <p>Suitable for potential super-startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
      <li>Unlimited Logo Concepts (6 Initial Concepts)</li>
      <li>Unlimited Revisions</li>
      <li>FREE Icon Design</li>
      <li>FREE Grayscale Format</li>
      <li>FREE Color Options</li>
      <li>FREE File Formats (PSD, PDF, AI, JPEG, PNG)</li>
      <li>FREE Vector Files</li>
      <li>Stationery Design(Business Card, Letterhead, Envelope, Invoice)</li>
      <li>6 Dedicated Designers</li>
      <li>48 hrs Turnaround Time</li>

      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
      
    </ul>
    
    <div class="price-btnwrap"> 
      <a href="<?php echo $path;?>ourpackages/gold-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=4" class="btn-packages">Place Your Order</a>
    </div>
  </div>

  <div class="smallbox">
    <h2>$144.99 <span><s>$289.98</s></span> </h2>
    <h4>Platinum Logo  <br> Package</h4>
    <p>Suitable for potential super-startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
      <li>Unlimited Logo Concepts (8 Initial Concepts )</li>
      <li>6 Dedicated Design Artists</li>
      <li>Unlimited Revisions</li>
      <li>2 Free Custom Startionery Designs (Letterhead, Envelope, Business Card, Invoice, Contract Cover Page Design)</li>
      <li>1 Double Sided Flyer Design</li>
      <li>FREE MS Word Letterhead</li>
      <li>Free Email Signature</li>
      <li>FREE Fax Template</li>
      <li>All Final File Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>
      <li>Facebook Banner Design</li>
      <li>Instagram Design</li>
      <li>Twitter Design</li>
      <li>YouTube Design</li>
      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/platinum-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=5" class="btn-packages">Place Your Order</a>
    </div>
  </div>

  <div class="smallbox">
    <h2>$144.99 <span><s>$289.98</s></span> </h2>
    <h4>Basic Illustration  <br> Logo  Package</h4>
    <p>Suitable for low level startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
      <li>2 Custom Logo Design Concepts</li>
      <li>1 Dedicated Designer</li>
      <li>2 Revision Rounds</li>
      <li>48 to 72 hours TAT</li>
      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/basic-illustration-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=6" class="btn-packages">Place Your Order</a>
    </div>
  </div>

  <div class="smallbox">
    <h2>$244.99 <span><s>$488.98</s></span> </h2>
    <h4>Startup Illustration  <br> Logo  Package</h4>
    <p>Suitable for mid level startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
       <li>5 Custom Logo Design Concepts</li>
      <li>2 Dedicated Designers</li>
      <li>FREE Icon</li>
      <li>Business Card Design</li>
      <li>6 Revision Rounds</li>
      <li>48 to 72 hours TAT</li>
      <li>All Final Files Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>

      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/startup-illustration-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=7" class="btn-packages">Place Your Order</a>
    </div>
  </div>

  <div class="smallbox">
    <h2>$344.99 <span><s>$688.98</s></span> </h2>
    <h4>Professional Illustration  <br> Logo  Package</h4>
    <p>Suitable for potential super-startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
      <li>8 Custom Logo Design Concepts</li>
      <li>4 Dedicated Designers</li>
      <li>Unlimited Revisions</li>
      <li>FREE Icon</li>
      <li>"FREE Custom Stationery Design (Letterhead, Envelope, Business Card)"</li>
      <li>FREE MS Word Letterhead</li>
      <li>24 to 48 hours TAT</li>
      <li>All Final File Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>

      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/professional-illustration-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=8" class="btn-packages">Place Your Order</a>
    </div>
  </div>

  <div class="smallbox">
    <h2>$394.99 <span><s>$788.98</s></span> </h2>
    <h4>3D logo  <br>   Package</h4>
    <p>Suitable for potential super-startups and brand revamps for existing companies</p>
    <div class="hrline"></div>
    <ul class="ticklist2 list-scroll">
      <li>3 Unique 3D Logo Concepts</li>
      <li>Light Effects and VFX</li>
      <li>Fully Rendered</li>
      <li>Multiple 3D Angles</li>
      <li>By 3 Award Winning Designers</li>
      <li>72 hours Turnaround Time</li>
      <li>UNLIMITED Revisions</li>
      <li class="heading">FEATURES</li>
      <li>100% Ownership Rights</li>
      <li>100% Satisfaction Guarantee</li>
      <li>100% Unique Design Guarantee</li>
      <li>100% Money Back Guarantee</li>
    </ul>
    <div class="price-btnwrap">
      <a href="<?php echo $path;?>ourpackages/3d-logo-package" class="vdetails">View Details</a>
      <a href="<?php echo $path;?>order?pack=9" class="btn-packages">Place Your Order</a>
    </div>
  </div>
  
</div>