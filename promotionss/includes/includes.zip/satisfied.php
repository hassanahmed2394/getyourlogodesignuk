<section class="mysatisfied">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="fullwrapper">
          <div class="leftwrap">
            <h3>SATISFIED CLIENTS<strong>50,000+</strong></h3>
          </div>
          <div class="rightwrap">
            <div class="coslider">

              <div>
                <ul class="countslide">
                  <li><h4>50000+</h4><p>Custom <br>Logo Designs</p></li>
                  <li><h4>6048+</h4><p>Single Page Websites (Parallax)</p></li>
                  <li><h4>7040+</h4><p>Responsive <br> Websites</p></li>
                  <li><h4>18357+</h4><p>Ecommerce <br> Websites</p></li>
                  <li class="nbr"><h4>50+</h4><p>Award Winning <br> Designers</p></li>
                </ul>
              </div>

              <div>
                <ul class="figureslide">
                  <li><p><span>100%</span> Money-back Guarantee</p></li>
                  <li><p><span>100%</span> Satisfaction Guaranteed</p></li>
                  <li><p><span>100%</span> Custom <br> Design</p></li>
                  <li><p>Unlimited <br> Revisions</p></li>
                  <li class="nbr"><p><span>24 / 7 </span> Customer Support</p></li>
                </ul>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>