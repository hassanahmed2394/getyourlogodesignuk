
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/1.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/1.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/2.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/2.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/3.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/3.png">
      </figure>
    </a>
  </li>
  
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/4.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/4.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/5.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/5.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/6.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/6.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/7.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/7.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/8.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/8.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/9.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/9.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/10.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/10.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/11.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/11.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/12.mp4">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/video/12.png">
      </figure>
    </a>
  </li>

<!--   <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/13.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/13.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/14.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/14.png">
      </figure>
    </a>
  </li>

  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/15.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/15.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect">
    <a class="" data-fancybox  href="javascript:;"  data-type="iframe" data-src="<?php echo $path;?><?php echo $basesurl;?>videos/16.mp4">
      <figure>
        <img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  data-src="<?php echo $basesurl;?>images/portfolio/video/16.png">
      </figure>
    </a>
  </li>
 -->

  

