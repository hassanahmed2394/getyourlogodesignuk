
  <div class="left">
    <h2>Video is king</h2>
    <h3>More than just Video animation</h3>
    <p>Video is the most effective medium to communicate in today’s time. At Get Your Logo Design, we believe in creating animated videos that are derived out of the essence of your brand. Get Your Logo Design works through videos to help you create, promote and sell.</p>
    <ul class="pointlisting">
      <li>Explainer videos</li>
      <li>Animated Commercial ads</li>
      <li>Educational video content</li>
      <li>Company story videos</li>
      <li>Whiteboard animation </li>
      <li>Tutorial videos</li>
    </ul>
    <a href="<?php echo $path;?>order" class="btn-theme-outline">Animate in just $209.99 </a>
  </div>
  <div class="right">
    <figure>
      <img src="<?php echo $basesurl;?>images/videoimage.svg">
    </figure>
  </div>
