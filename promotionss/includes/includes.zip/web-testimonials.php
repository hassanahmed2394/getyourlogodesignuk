<section class="dptestimonials">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>We help you create brands that build businesses.</h2>
        <p>Trusted by thousands of brands from every industry.</p>

        <ul class="testwrap testslider">
          <li>
            <div class="testbox">
              <div class="user">
                <h3>AM</h3>
              </div>
              <div class="usertest">
                <h4>Brilliant Responsive Work</h4>
                <p>We talk regarding web design services for our website and how it was affecting our rankings. The team provided us responsive web design services and SEO consultation too!</p>
                <h6>Antionio Moreno, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star-half-empty"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>EB</h3>
              </div>
              <div class="usertest">
                <h4>Excellent Web Consultation For My Website</h4>
                <p>I was a bit confused when I got to LDH, and the excellent team helped us along the way! We’re more than happy working with them.</p>
                <h6>Erika Blackwell, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>JS</h3>
              </div>
              <div class="usertest">
                <h4>Super Amazing Branding Service</h4>
                <p>Get Your Logo Design amazingly created a logo and then web design team gave my online store a whole new look! I am extremely overwhelmed by the services provided.</p>
                <h6>Justin Sundling, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                </div>
              </div>
            </div>
          </li> 
                   
        </ul>
      </div>
    </div>
  </div>
</section>